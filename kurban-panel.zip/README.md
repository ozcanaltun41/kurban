# Kurban Panel

Bu proje, kurbanlık satış ve hisse takip sistemidir.
